package com.example.a2340_frogger;

public class DataHolder {
    private static DataHolder instance;

    private DataHolder() {
        this.difficulty = "Easy";
        this.multiplier = 1;
        this.health = 0;
    }

    public static DataHolder getInstance() {
        if (instance == null) {
            instance = new DataHolder();
        }
        return instance;
    }

    private static String difficulty;
    private static int multiplier;
    private static int health;
    private static int lives = 5;

    public static void setLives(int life) {
        lives = life;
    }

    public static int getLives() {
        return lives;
    }
    public String getDifficulty() {
        return this.difficulty;
    }

    public static void setDifficulty(String diff) {
        difficulty = diff;
    }

    public static int getMultiplier() {
        return multiplier;
    }

    public void setMultiplier(int multiplier) {
        this.multiplier = multiplier;
    }

    public static int getHealth() {
        return health;
    }

    public static void setHealth(int heal) {
        health = heal;
    }
}
