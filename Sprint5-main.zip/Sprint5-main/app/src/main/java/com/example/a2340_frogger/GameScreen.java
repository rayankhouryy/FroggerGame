package com.example.a2340_frogger;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class GameScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);
        TextView startName = (TextView) findViewById(R.id.startName);
        TextView monHealth = (TextView) findViewById(R.id.monumentHealth);
        TextView difficulty = (TextView) findViewById(R.id.showdifficulty);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.gametoolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle(null);

        DataHolder data = DataHolder.getInstance();
        startName.setText("Lives: " + DataHolder.getLives());
        monHealth.setText("Score: " + data.getHealth());
        difficulty.setText("Difficulty: " + data.getDifficulty());


        Button upButton = (Button) findViewById(R.id.up);

        ImageView image = findViewById(R.id.imagee);
        image.setX(700);
        image.setY(2750);

        ImageView car = findViewById(R.id.download);
        car.setX(10);
        car.setY(1720);

        ObjectAnimator animation = ObjectAnimator.ofFloat(car, "translationX", 700f);
        animation.setDuration(4000);
        animation.start();

        ImageView car2 = findViewById(R.id.carr);
        car2.setX(180);
        car2.setY(1920);

        ObjectAnimator animatio = ObjectAnimator.ofFloat(car2, "translationX", -700f);
        animatio.setDuration(4000);
        animatio.start();

        ImageView car3 = findViewById(R.id.car4);
        car3.setX(10);
        car3.setY(2120);

        ObjectAnimator animati = ObjectAnimator.ofFloat(car3, "translationX", 700f);
        animati.setDuration(2000);
        animati.start();

        ImageView car4 = findViewById(R.id.car5);
        car4.setX(240);
        car4.setY(2330);

        ImageView car5 = findViewById(R.id.car6);
        car5.setX(150);
        car5.setY(2550);

        ImageView log1 = findViewById(R.id.log1);
        log1.setX(-400);
        log1.setY(1250);


        if (upButton != null) {
            upButton.setOnClickListener((View.OnClickListener) (new View.OnClickListener() {
                public final void onClick(View it) {
                    int maxnum = 0;
                    if (image.getY() > 200) {
                        image.setY(image.getY() - 210);
                        DataHolder.setHealth(DataHolder.getHealth() + 1);
                        monHealth.setText("Score: " + data.getHealth());
                        if (DataHolder.getHealth() > maxnum) {
                            maxnum = DataHolder.getHealth();
                        }
                        /*if (image.getY() < 1200 && DataHolder.getLives() > 0) {
                            DataHolder.setHealth(DataHolder.getHealth() + 1);
                            monHealth.setText("Score: " + data.getHealth());
                            DataHolder.setLives(DataHolder.getLives() - 1);
                            image.setY(2750);
                            startName.setText("Lives: " + DataHolder.getLives());
                            DataHolder.setHealth(0);
                            monHealth.setText("Score: " + data.getHealth());*/
                        if (DataHolder.getLives() == 0) {
                            DataHolder.setHealth(maxnum);
                            Intent j = new Intent(GameScreen.this, MainActivity.class);
                            startActivity(j);
                        }
                    }

                    if ((image.getY() < 2700 && image.getY() > 2400)
                            && (image.getX() > 500 && image.getX() < 750)) {
                        if (DataHolder.getLives() > 0) {
                            DataHolder.setLives(DataHolder.getLives() - 1);
                            image.setY(2750);
                            startName.setText("Lives: " + DataHolder.getLives());
                            DataHolder.setHealth(0);
                            monHealth.setText("Score: " + data.getHealth());
                        } else if (DataHolder.getLives() == 0) {
                            Intent j = new Intent(GameScreen.this, MainActivity.class);
                            startActivity(j);
                        }
                    }
                }
            }));
        }

        Button downButton = (Button) findViewById(R.id.down);

        if (downButton != null) {
            downButton.setOnClickListener((View.OnClickListener) (new View.OnClickListener() {
                public final void onClick(View it) {
                    if (image.getY() < 2700) {
                        image.setY(image.getY() + 210);
                    }
                }
            }));
        }

        Button leftButton = (Button) findViewById(R.id.left);

        if (leftButton != null) {
            leftButton.setOnClickListener((View.OnClickListener) (new View.OnClickListener() {
                public final void onClick(View it) {
                    if (image.getX() > 20) {
                        image.setX(image.getX() - 100);
                    }
                }
            }));
        }

        Button rightButton = (Button) findViewById(R.id.right);

        if (rightButton != null) {
            rightButton.setOnClickListener((View.OnClickListener) (new View.OnClickListener() {
                public final void onClick(View it) {
                    if (image.getX() < 1300) {
                        image.setX(image.getX() + 100);
                    }
                }
            }));
        }
    }
}