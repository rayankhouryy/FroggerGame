package com.example.a2340_frogger;

/**
 * This class handles the difficulty of the game
 */

public class GameController {
    private DataHolder h;

    public GameController(DataHolder h) {
        this.h = h.getInstance();
    }

    // this method is used to calculate initial conditions
    public void calculateMultiplier() {
        if (h.getDifficulty().equals("Easy")) { //  when the difficulty is set to easy, the multipler is set to 1
            h.setMultiplier(1);
        } else if (h.getDifficulty().equals("Medium")) { //  when the difficulty is set to medium, the multipler is set to 2
            h.setMultiplier(2);
        } else {
            h.setMultiplier(3); //  when the difficulty is set to hard, the multipler is set to 3
        }
    }

    public void calculateMonumentHealth() {
        h.setHealth(0);
    }
}

