package com.example.a2340_frogger;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.simpleButton1);
        Button button2 = (Button) findViewById(R.id.simpleButton2);

        if (button != null) {
            button.setOnClickListener((View.OnClickListener) (new View.OnClickListener() {
                public final void onClick(View it) {

                    Intent intent = new Intent(
                            MainActivity.this, ConfigurationScreen.class);
                    startActivity(intent);
                }
            }));
        }

        if (button2 != null) {
            button2.setOnClickListener((View.OnClickListener) (new View.OnClickListener() {
                public final void onClick(View it) {
                    finish();
                }
            }));
        }
    }
}