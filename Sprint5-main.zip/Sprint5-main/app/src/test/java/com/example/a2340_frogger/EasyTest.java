package com.example.a2340_frogger;

import org.junit.Test;

import static org.junit.Assert.*;

public class EasyTest {
    @Test
    public void EasyTest() {
        DataHolder.getInstance();
        assertEquals(DataHolder.getMultiplier(), 1);
        assertEquals(DataHolder.getHealth(), 100);
    }
}
