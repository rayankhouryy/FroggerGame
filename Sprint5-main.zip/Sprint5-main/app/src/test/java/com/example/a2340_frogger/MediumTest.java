package com.example.a2340_frogger;

import org.junit.Test;

import static org.junit.Assert.*;

public class MediumTest {
    @Test
    public void MediumTest() {
        DataHolder.setDifficulty("Medium");
        assertEquals(DataHolder.getMultiplier(), 0);
    }
}