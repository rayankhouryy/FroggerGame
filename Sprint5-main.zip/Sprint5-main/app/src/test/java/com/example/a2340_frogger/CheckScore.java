package com.example.a2340_frogger;

import org.junit.Test;

import static org.junit.Assert.*;


public class CheckScore {
    @Test
    public void CheckScore() {
        DataHolder.setHealth(7);
        assertEquals(DataHolder.getHealth(), 7);
    }
}
