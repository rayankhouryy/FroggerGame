package com.example.a2340_frogger;

import org.junit.Test;

import static org.junit.Assert.*;

public class CheckLives {
    @Test
    public void CheckScore() {
        assertEquals(DataHolder.getLives(), 5);
    }
}
