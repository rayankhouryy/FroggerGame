package com.example.a2340_frogger;

import org.junit.Test;

import static org.junit.Assert.*;

public class HardTest {
    @Test
    public void HardTest() {
        DataHolder.setDifficulty("Hard");
        assertEquals(DataHolder.getMultiplier(), 0);
    }
}
